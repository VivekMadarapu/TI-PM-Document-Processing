import json
import pandas as pd

def load_json(file_path):
    """
    Load the JSON file content.
    """
    with open(file_path, "r") as file:
        return json.load(file)

def process_json_to_check_sheet(data):
    """
    Process JSON data and extract lines into a tabular structure for the check sheet.
    """
    check_sheet_data = []
    
    # Ensure 'processed_lines' exists in the JSON structure
    if "processed_lines" not in data:
        print("The JSON data does not contain 'processed_lines'.")
        return check_sheet_data
    
    for entry in data.get("processed_lines", []):
        line_number = entry.get("line_number", "")
        original_text = entry.get("original_text", "")
        ambiguous_words = ", ".join(entry.get("ambiguous_words", [])) if entry.get("ambiguous_words") else "None"
        
        check_sheet_data.append({
            "Line Number": line_number,
            "Task/Statement": original_text,
            "Ambiguous Words": ambiguous_words
        })
    
    return check_sheet_data

def save_to_excel(data, output_file):
    """
    Save processed data to an Excel file.
    """
    if not data:
        print("No data available to save.")
        return
    
    df = pd.DataFrame(data)
    df.to_excel(output_file, index=False)
    print(f"Check sheet saved to {output_file}")

def main():
    """
    Main function to execute the script.
    """
    # Input and output file paths
    response_file = "response.json"  # Replace with the actual JSON file path
    output_excel = "check_sheet.xlsx"  # Output Excel file
    
    try:
        # Load JSON content
        data = load_json(response_file)
        
        # Process JSON data
        check_sheet_data = process_json_to_check_sheet(data)
        
        # Debug: Print data to verify before saving
        if check_sheet_data:
            print("Processed data preview:")
            print(pd.DataFrame(check_sheet_data).head())
        else:
            print("No data processed. Please verify the JSON structure.")
        
        # Save to Excel
        save_to_excel(check_sheet_data, output_excel)
    
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
